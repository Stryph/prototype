package health;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Data
@Entity
class Person {

	private @Id @GeneratedValue Long id;
	private String name;
	private float weightLbs;

	Person(String name, float weightLbs) {
		this.name = name;
		this.weightLbs = weightLbs;
	}
}